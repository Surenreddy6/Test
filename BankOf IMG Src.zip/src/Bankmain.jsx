import { Link } from "react-router-dom";

const Home = () => {
  return (
    <section>
      <div align="Left">
        <h3 style={{ color: "blue"}}>Please select appropiate one</h3>

        <button className="btn btn-dark">
          <h4 >New Customer</h4>
          <Link to="/create">Login</Link>
        </button>
        <br /><br />
        <button className="btn btn-dark">
          <h4>Employee Login</h4>
          <Link to="/empdata">Login</Link>
        </button>
      </div>
    </section>
  );
};

export default Home;
