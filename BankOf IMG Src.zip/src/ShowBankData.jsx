import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import axios from "axios";
import { useEffect,useState } from "react";
import "./App.css";


const ShowData = () => {
  
  const [data, setData]= useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:9999/BankData")
      .then((res) => setData(res.data))
      .catch((err) => console.log(err));
  }, []);
  
  const handleDelete = (id) => {
    const confirm = window.confirm("sure about it?");
    if (confirm) {
      axios
        .delete(`http://localhost:9999/BankData/${id}`)
        .then((res) => {
          // log the id here
          window.location.reload();
          console.log(res);
        })
        .catch((err) => console.log(err));
    }
    console.log(id);
  };

  return (
    
    <div><br/>
<button className="btn btn-primary">
            <Link to="/" style={{color:"white"}}>Logout</Link>
          </button>
        <table className="table">
          <thead>
            <tr>
              <th>Customer ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Maidan Name</th>
              <th>Age</th>
              <th>Gender</th>
              <th>E-Mail</th>
              <th>Balance Amount</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.map((row,index)=>(
              <tr key={index}>
              <td>{row.id}</td>
              <td>{row.firstname}</td>
              <td>{row.lastname}</td>
              <td>{row.maidanname}</td>
              <td>{row.age}</td>
              <td>{row.gender}</td>
              <td>{row.gmail}</td>
              <td>{row.amount}</td>
              <td>
                <Link to={`/update/${row.id}`}>
                  <button >UPDATE</button>
                </Link>&ensp;
                <button className="btn btn-dark" onClick={() => handleDelete(row.id)}>
                  DELETE
                </button></td>
            </tr>
            )
            )
            }
            
          </tbody>
        </table>
    </div>
  );
};

ShowData.propTypes = {
  id: PropTypes.number.isRequired,
  firstname: PropTypes.string.isRequired,
  lastname: PropTypes.string.isRequired,
  maidanname: PropTypes.string.isRequired,
  age: PropTypes.number.isRequired,
  gender: PropTypes.string.isRequired,
  gmail: PropTypes.string.isRequired,
  amount: PropTypes.number.isRequired,
};

export default ShowData;
